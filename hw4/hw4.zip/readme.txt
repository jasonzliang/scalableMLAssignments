type "make" to build source code
usage: ./hw4

example test matrix is provided in data directory. To use different matrix, modify the input file names in problem.cpp. The matrix format is the following:

{sparse_matrix}.txt, where each line is row, col, value (separated by whitespace)

{sparse_maxtrix}.meta with the following metadata:
rows col num_entries

