requires eigen library in same directory as source code.
to build, type "make"